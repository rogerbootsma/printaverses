"""Check real TLS validation and HTTP redirects without bypassing certificates."""
import http.client
import json
import ssl
import sys
from datetime import datetime, timezone

results = []
for host in sys.argv[1:]:
    result = {'host': host, 'checked': datetime.now(timezone.utc).isoformat()}
    connection = http.client.HTTPSConnection(host, timeout=8, context=ssl.create_default_context())
    try:
        connection.request('HEAD', '/')
        certificate = connection.sock.getpeercert()
        response = connection.getresponse()
        result.update(tls_valid=True, https_status=response.status, https_location=response.getheader('Location'), certificate_expires=certificate.get('notAfter'))
        connection.close()
        plain = http.client.HTTPConnection(host, timeout=8)
        plain.request('HEAD', '/')
        response = plain.getresponse()
        result.update(http_status=response.status, http_location=response.getheader('Location'))
        plain.close()
    except Exception as error:
        result.update(tls_valid=False, error=f'{type(error).__name__}: {error}')
        connection.close()
    results.append(result)
    print(json.dumps(result), flush=True)
