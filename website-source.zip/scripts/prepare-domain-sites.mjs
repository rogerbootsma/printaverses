import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
const root=path.resolve(import.meta.dirname,'..');
const map=JSON.parse(fs.readFileSync(path.join(root,'domain-map.json'),'utf8'));
assert.equal(map.brands.length,19);
for(const {domain,destination} of map.brands){
 assert.match(domain,/^[a-z]+\.com$/);
 assert.match(destination,/^https:\/\/printaverses\.com\/[a-z]+\/$/);
 const directory=path.join(root,'domain-sites',domain);
 fs.mkdirSync(directory,{recursive:true});
 fs.writeFileSync(path.join(directory,'CNAME'),domain+'\n');
 fs.writeFileSync(path.join(directory,'.nojekyll'),'');
 fs.writeFileSync(path.join(directory,'index.html'),`<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="referrer" content="no-referrer"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; base-uri 'none'; form-action 'none'"><meta http-equiv="refresh" content="0;url=${destination}"><link rel="canonical" href="${destination}"><title>${domain} | Printaverses</title></head><body><main><h1>${domain}</h1><p>This collection is part of Printaverses.</p><p><a href="${destination}">Continue to the collection</a></p></main><footer><p>© 2026 Metaversal Arts. Metaversalarts e.U. · Roger Bootsma · Vienna, Austria · FN 687427 y</p><a href="https://printaverses.com/legal/">Legal notice / Impressum</a> · <a href="https://printaverses.com/privacy/">Privacy</a> · <a href="https://printaverses.com/">Printaverses home</a></footer></body></html>\n`);
}
console.log('Prepared 19 fixed HTTPS redirect sites with business attribution. DNS remains unchanged.');
