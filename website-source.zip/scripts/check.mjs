import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
const root=path.resolve(import.meta.dirname,'../dist');
const pages=[];
function walk(dir){for(const entry of fs.readdirSync(dir,{withFileTypes:true})){const file=path.join(dir,entry.name);if(entry.isDirectory())walk(file);else if(file.endsWith('.html'))pages.push(file);}}
walk(root);
let references=0;
const failures=[];
for(const page of pages){
 const html=fs.readFileSync(page,'utf8');
 if(!html.includes('<title>'))failures.push(`${page}: missing title`);
 if(!html.includes('name="viewport"'))failures.push(`${page}: missing viewport`);
 if(!html.includes('http-equiv="refresh"')&&(html.match(/<h1[ >]/g)||[]).length!==1)failures.push(`${page}: expected one h1`);
 for(const match of html.matchAll(/(?:src|href)="([^"#][^"]*)"/g)){
  const ref=match[1]; if(/^(?:https?:|data:|mailto:|tel:)/.test(ref))continue;
  let file=path.resolve(path.dirname(page),ref.split('#')[0]);
  if(fs.existsSync(file)&&fs.statSync(file).isDirectory())file=path.join(file,'index.html');
  if(!fs.existsSync(file))failures.push(`${path.relative(root,page)}: missing ${ref}`);
  references++;
 }
 for(const match of html.matchAll(/<img\b[^>]*>/g))if(!match[0].includes('alt='))failures.push(`${page}: image without alt`);
}
assert.equal(failures.length,0,failures.join('\n'));
assert.equal(pages.length,23,'Expected hub + 17 brands + 2 aliases + about + legal + privacy');
for(const page of pages){
 const html=fs.readFileSync(page,'utf8');
 assert.ok(html.includes('Content-Security-Policy'),`${page}: content policy missing`);
 assert.ok(html.includes('Metaversalarts e.U.'),`${page}: business attribution missing`);
 assert.ok(!/src="https?:\/\//.test(html),`${page}: unexpected external asset`);
}
console.log(`PASS: ${pages.length} pages, ${references} local references, image alt text and page metadata.`);
